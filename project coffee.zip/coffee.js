let menu = document.querySelector('#menu-btn');
let navbar = document.querySelector('.header .menu .icon');

menu.onclick = () => {
    menu.classList.toggle(' fa-bars');
}